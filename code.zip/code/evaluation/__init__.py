"""
Ghost Audit evaluation package.
"""
